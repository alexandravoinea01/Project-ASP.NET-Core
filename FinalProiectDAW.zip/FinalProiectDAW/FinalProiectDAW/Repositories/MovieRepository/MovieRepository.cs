﻿using FinalProiectDAW.Data;
using FinalProiectDAW.Entities;
using FinalProiectDAW.Repositories.GenericRepository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Repositories.MovieRepository
{
    public class MovieRepository : GenericRepository<Movie>, IMovieRepository
    {
        public MovieRepository(Context context) : base(context) { }

        public async Task<List<Movie>> GetByGenre(string genre)
        {
            return await _context.Movies.Where(m => m.Genre.Equals(genre)).ToListAsync();
        }

        public async Task<Movie> GetByTitle(string title)
        {
            return await _context.Movies.Where(m => m.Title.Equals(title)).FirstOrDefaultAsync();
        }

        public async Task<List<Movie>> GetByYear(int year)
        {
            return await _context.Movies.Where(m => m.Year == year).ToListAsync();
        }

        public async Task<List<Movie>> GetAllWithStudio()
        {
            return await _context.Movies.Include(m => m.Studio).ToListAsync();
        }
    }
}
