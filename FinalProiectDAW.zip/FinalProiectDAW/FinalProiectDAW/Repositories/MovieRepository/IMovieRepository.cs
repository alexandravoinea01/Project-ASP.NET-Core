﻿using FinalProiectDAW.Entities;
using FinalProiectDAW.Repositories.GenericRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Repositories.MovieRepository
{
    public interface IMovieRepository : IGenericRepository<Movie>
    {
        Task<Movie> GetByTitle(string title);
        Task<List<Movie>> GetByGenre(string genre);
        Task<List<Movie>> GetByYear(int year);

        Task<List<Movie>> GetAllWithStudio();
    }
}
