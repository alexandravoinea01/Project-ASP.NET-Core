﻿using FinalProiectDAW.Data;
using FinalProiectDAW.Entities;
using FinalProiectDAW.Repositories.GenericRepository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Repositories.ProducerRepository
{
    public class ProducerRepository : GenericRepository<Producer>, IProducerRepository
    {
        public ProducerRepository(Context context) : base(context) { }

        public async Task<List<Producer>> GetActiveSince(int year)
        {
            return await _context.Producers.Where(p => p.ActiveSince <= year).ToListAsync();
        }

        public async Task<List<Producer>> GetByLastName(string lastName)
        {
            return await _context.Producers.Where(p => p.LastName.Equals(lastName)).ToListAsync();
        }
    }
}
