﻿using FinalProiectDAW.Entities;
using FinalProiectDAW.Repositories.GenericRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Repositories.ProducerRepository
{
    public interface IProducerRepository : IGenericRepository<Producer>
    {
        Task<List<Producer>> GetByLastName(string lastName);
        Task<List<Producer>> GetActiveSince(int year);
    }
}
