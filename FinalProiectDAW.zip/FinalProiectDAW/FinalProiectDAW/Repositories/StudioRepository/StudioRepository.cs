﻿using FinalProiectDAW.Data;
using FinalProiectDAW.Entities;
using FinalProiectDAW.Repositories.GenericRepository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Repositories.StudioRepository
{
    public class StudioRepository : GenericRepository<Studio>, IStudioRepository
    {
        public StudioRepository(Context context) : base(context) { }

        public async Task<List<Studio>> GetByFoundingYear(int year)
        {
            return await _context.Studios.Where(s => s.FoundingYear == year).ToListAsync();
        }

        public async Task<Studio> GetByName(string name)
        {
            return await _context.Studios.Where(s => s.StudioName.Equals(name)).FirstOrDefaultAsync();
        }

        public async Task<List<Studio>> GetAllWithLocationAndMovies()
        {
            return await _context.Studios.Include(s => s.LocationStudio).Include(s => s.Movies).ToListAsync();
        }
    }
}
