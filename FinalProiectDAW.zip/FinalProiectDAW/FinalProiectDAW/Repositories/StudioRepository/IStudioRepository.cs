﻿using FinalProiectDAW.Entities;
using FinalProiectDAW.Repositories.GenericRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Repositories.StudioRepository
{
    public interface IStudioRepository : IGenericRepository<Studio>
    {
        Task<Studio> GetByName(string name);
        Task<List<Studio>> GetByFoundingYear(int year);
        Task<List<Studio>> GetAllWithLocationAndMovies();
    }
}
