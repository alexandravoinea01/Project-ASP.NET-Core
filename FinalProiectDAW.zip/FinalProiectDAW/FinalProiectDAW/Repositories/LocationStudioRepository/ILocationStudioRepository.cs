﻿using FinalProiectDAW.Entities;
using FinalProiectDAW.Repositories.GenericRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Repositories.LocationStudioRepository
{
    public interface ILocationStudioRepository : IGenericRepository<LocationStudio>
    {
        Task<LocationStudio> GetByCity(string city);
        Task<List<LocationStudio>> GetAllLocationsWithStudio();
        Task<LocationStudio> GetByIdWithStudio(int id);
    }
}
