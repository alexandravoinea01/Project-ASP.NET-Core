﻿using FinalProiectDAW.Data;
using FinalProiectDAW.Entities;
using FinalProiectDAW.Repositories.GenericRepository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Repositories.LocationStudioRepository
{
    public class LocationStudioRepository : GenericRepository<LocationStudio>, ILocationStudioRepository
    {
        public LocationStudioRepository(Context context) : base(context) { }

        public async Task<List<LocationStudio>> GetAllLocationsWithStudio()
        {
            return await _context.LocationStudios.Include(l => l.Studio).ToListAsync();
        }

        public async Task<LocationStudio> GetByIdWithStudio(int id)
        {
            return await _context.LocationStudios.Include(l => l.Studio).Where(l => l.Id == id).FirstOrDefaultAsync();
        }

        public async Task<LocationStudio> GetByCity(string city)
        {
            return await _context.LocationStudios.Where(l => l.City.Equals(city)).FirstOrDefaultAsync();
        }
    }
}
