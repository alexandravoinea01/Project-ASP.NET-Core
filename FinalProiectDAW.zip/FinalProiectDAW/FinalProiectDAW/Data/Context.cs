﻿using FinalProiectDAW.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Data
{
    public class Context : IdentityDbContext<User, Role, string, IdentityUserClaim<string>,
                           UserRole, IdentityUserLogin<string>, IdentityRoleClaim<string>, 
                           IdentityUserToken<string>>
    {
        public Context(DbContextOptions<Context> options) : base(options) { }
        public DbSet<LocationStudio> LocationStudios { get; set; }
        public DbSet<Studio> Studios { get; set; }
        public DbSet<Movie> Movies { get; set; }
        public DbSet<Producer> Producers { get; set; }
        public DbSet<ProducerMovie> ProducerMovies { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //Studio - Location : one-to-one

            modelBuilder.Entity<Studio>()
                .HasOne(s => s.LocationStudio)
                .WithOne(l => l.Studio);

            //Studio - Movie : one-to-many

            modelBuilder.Entity<Studio>()
                .HasMany(s => s.Movies)
                .WithOne(m => m.Studio);

            //Producer - Movie : many-to-many

            modelBuilder.Entity<ProducerMovie>()
                .HasKey(pm => new { pm.ProducerId, pm.MovieId });

            modelBuilder.Entity<ProducerMovie>()
                .HasOne(pm => pm.Producer)
                .WithMany(p => p.ProducerMovies)
                .HasForeignKey(pm => pm.ProducerId);

            modelBuilder.Entity<ProducerMovie>()
                .HasOne(pm => pm.Movie)
                .WithMany(m => m.ProducerMovies)
                .HasForeignKey(pm => pm.MovieId);


            base.OnModelCreating(modelBuilder);
        }
    }
}
