﻿using FinalProiectDAW.Entities;
using FinalProiectDAW.Entities.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Managers.MovieManager
{
    public interface IMovieManager
    {
        Task<MovieDTO> GetByTitle(string title);
        Movie GetByIdAsync(int id);
        Task<List<MovieDTO>> GetByGenre(string genre);
        Task<List<MovieDTO>> GetByYear(int year);
        Task<List<MovieDTO>> GetAllWithStudio();
        void Create(CreateMovieDTO dto);
        void Update(int id, CreateMovieDTO dto);
        void Delete();
        void Delete(int id);
    }
}
