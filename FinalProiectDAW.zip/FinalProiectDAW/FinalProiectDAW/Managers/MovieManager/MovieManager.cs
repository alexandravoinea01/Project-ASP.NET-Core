﻿using FinalProiectDAW.Entities;
using FinalProiectDAW.Entities.DTOs;
using FinalProiectDAW.Managers.StudioManager;
using FinalProiectDAW.Repositories.MovieRepository;
using FinalProiectDAW.Repositories.StudioRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Managers.MovieManager
{
    public class MovieManager : IMovieManager
    {
        private readonly IMovieRepository _repository;
        private readonly IStudioManager _manStu;
        public MovieManager(IMovieRepository repository, IStudioManager manStu)
        {
            _repository = repository;
            _manStu = manStu;
        }

        public async void Create(CreateMovieDTO dto)
        {
            Movie newMovie = new Movie();
            newMovie.Title = dto.Title;
            newMovie.Year = dto.Year;
            newMovie.Genre = dto.Genre;
            newMovie.Price = dto.Price;

            var studio = _manStu.GetByIdAsync(dto.StudioId);

            if (studio == null)
                return; 

            newMovie.StudioId = dto.StudioId;

            _repository.Create(newMovie);
        }

        public async void Delete()
        {
            var movies = _repository.GetAll();
            if (movies == null)
                return;
            _repository.DeleteRange(movies);
        }

        public async void Delete(int id)
        {
            var movie = GetByIdAsync(id);
            if (movie == null)
                return;
            _repository.Delete(movie);
        }

        public async Task<List<MovieDTO>> GetAllWithStudio()
        {
            var movies = await _repository.GetAllWithStudio();
            if (movies.Count() == 0)
                return null;
            var moviesToReturn = new List<MovieDTO>();
            foreach (var movie in movies)
            {
                moviesToReturn.Add(new MovieDTO(movie));
            }
            return moviesToReturn;
        }

        public async Task<List<MovieDTO>> GetByGenre(string genre)
        {
            var movies = await _repository.GetByGenre(genre);
            if (movies.Count() == 0)
                return null;
            var moviesToReturn = new List<MovieDTO>();
            foreach (var movie in movies)
            {
                moviesToReturn.Add(new MovieDTO(movie));
            }
            return moviesToReturn;
        }

        public Movie GetByIdAsync(int id)
        {
            var movie = _repository.GetAll().FirstOrDefault(x => x.Id == id);
            return movie;
        }

        public async Task<MovieDTO> GetByTitle(string title)
        {
            var movie = await _repository.GetByTitle(title);
            if (movie == null)
                return null;
            return new MovieDTO(movie);
        }

        public async Task<List<MovieDTO>> GetByYear(int year)
        {
            var movies = await _repository.GetByYear(year);
            if (movies.Count() == 0)
                return null;
            var moviesToReturn = new List<MovieDTO>();
            foreach (var movie in movies)
            {
                moviesToReturn.Add(new MovieDTO(movie));
            }
            return moviesToReturn;
        }

        public async void Update(int id, CreateMovieDTO dto)
        {
            var movie = GetByIdAsync(id);
            movie.Title = dto.Title;
            movie.Year = dto.Year;
            movie.Genre = dto.Genre;
            movie.Price = dto.Price;
            movie.StudioId = dto.StudioId;

            var studio = _manStu.GetByIdAsync(dto.StudioId);

            if (studio != null)
                movie.Studio = studio;
            else
                movie.Studio = dto.Studio;

            _repository.Update(movie);
        }
    }
}
