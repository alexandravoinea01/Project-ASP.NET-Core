﻿using FinalProiectDAW.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Managers.TokenManager
{
    public interface ITokenManager
    {
        Task<string> CreateToken(User user);
    }
}
