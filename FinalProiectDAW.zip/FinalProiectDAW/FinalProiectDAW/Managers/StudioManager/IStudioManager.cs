﻿using FinalProiectDAW.Entities;
using FinalProiectDAW.Entities.DTOs;
using FinalProiectDAW.Repositories.LocationStudioRepository;
using FinalProiectDAW.Repositories.StudioRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Managers.StudioManager
{
    public interface IStudioManager
    {
        Task<StudioDTO> GetByName(string name);
        Task<List<StudioDTO>> GetByFoundingYear(int year);
        Task<List<StudioDTO>> GetAllWithLocationAndMovies();
        Studio GetByIdAsync(int id);
        void Create(CreateStudioDTO dto);
        void Update(int id, CreateStudioDTO dto);
        void Delete(int id);
        void Delete();
    }
}
