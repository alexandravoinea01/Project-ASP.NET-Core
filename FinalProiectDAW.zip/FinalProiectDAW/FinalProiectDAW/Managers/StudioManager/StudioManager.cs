﻿using FinalProiectDAW.Entities;
using FinalProiectDAW.Entities.DTOs;
using FinalProiectDAW.Managers.LocationManager;
using FinalProiectDAW.Repositories.LocationStudioRepository;
using FinalProiectDAW.Repositories.StudioRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Managers.StudioManager
{
    public class StudioManager : IStudioManager
    {
        private readonly IStudioRepository _repository;
        private readonly ILocationStudioManager _manLoc;
        public StudioManager(IStudioRepository repository, ILocationStudioManager manLoc)
        {
            _repository = repository;
            _manLoc = manLoc;
        }

        public async void Create(CreateStudioDTO dto)
        {
            var newStudio = new Studio();
            newStudio.StudioName = dto.StudioName;
            newStudio.FoundingYear = dto.FoundingYear;
            newStudio.Owner = dto.Owner;

            var location = _manLoc.GetByIdAsync(dto.LocationStudioId);
            if (location == null)
                return;

            newStudio.LocationStudioId = dto.LocationStudioId;

            _repository.Create(newStudio);
        }

        public async void Delete(int id)
        {
            var studio = GetByIdAsync(id);
            if (studio == null)
                return;
            _repository.Delete(studio);
        }

        public void Delete()
        {
            var studios = _repository.GetAll();
            if (studios.Count() == 0)
                return;
            _repository.DeleteRange(studios);
        }

        public async Task<List<StudioDTO>> GetAllWithLocationAndMovies()
        {
            var studios = await _repository.GetAllWithLocationAndMovies();
            var studiosToReturn = new List<StudioDTO>();
            foreach (var studio in studios)
            {
                studiosToReturn.Add(new StudioDTO(studio));
            }
            return studiosToReturn;
        }

        public async Task<List<StudioDTO>> GetByFoundingYear(int year)
        {
            var studios = await _repository.GetByFoundingYear(year);
            if (studios.Count() == 0)
                return null;
            var studiosToReturn = new List<StudioDTO>();
            foreach (var studio in studios)
            {
                studiosToReturn.Add(new StudioDTO(studio));
            }
            return studiosToReturn;
        }

        public Studio GetByIdAsync(int id)
        {
            var studio = _repository.GetAll().FirstOrDefault(x => x.Id == id);
            return studio;
        }

        public async Task<StudioDTO> GetByName(string name)
        {
            var studio = await _repository.GetByName(name);
            if (studio == null)
                return null;
            return new StudioDTO(studio);
        }

        public async void Update(int id, CreateStudioDTO dto)
        {
            var studio = GetByIdAsync(id);
            studio.StudioName = dto.StudioName;
            studio.FoundingYear = dto.FoundingYear;
            studio.Owner = dto.Owner;

            var location = _manLoc.GetByIdAsync(dto.LocationStudioId);
            if (location != null)
                studio.LocationStudio = location;
            else
                studio.LocationStudio = dto.LocationStudio;

            studio.LocationStudioId = dto.LocationStudioId;

            _repository.Update(studio);
        }
    }
}
