﻿using FinalProiectDAW.Entities;
using FinalProiectDAW.Entities.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Managers.LocationManager
{
    public interface ILocationStudioManager
    {
        Task<LocationStudioDTO> GetByCity(string city);
        Task<List<LocationStudioDTO>> GetAllLocationsWithStudio();
        Task<LocationStudioDTO> GetByIdWithStudio(int id);
        LocationStudio GetByIdAsync(int id);
        void Create(CreateLocationStudioDTO dto);
        void Delete(int id);
        void Delete();
        void Update(int id, CreateLocationStudioDTO dto);
    }
}
