﻿using FinalProiectDAW.Entities;
using FinalProiectDAW.Entities.DTOs;
using FinalProiectDAW.Managers.LocationManager;
using FinalProiectDAW.Repositories.LocationStudioRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Managers.LocationStudioManager
{
    public class LocationStudioManager : ILocationStudioManager
    {
        private readonly ILocationStudioRepository _repository;
        public LocationStudioManager(ILocationStudioRepository repository)
        {
            _repository = repository;
        }
        public async Task<List<LocationStudioDTO>> GetAllLocationsWithStudio()
        {
            var locations = await _repository.GetAllLocationsWithStudio();
            var locationsToReturn = new List<LocationStudioDTO>();
            foreach (var location in locations)
            {
                locationsToReturn.Add(new LocationStudioDTO(location));
            }
            return locationsToReturn;
        }

        public async Task<LocationStudioDTO> GetByCity(string city)
        {
            var location = await _repository.GetByCity(city);
            if (location == null)
                return null;
            return new LocationStudioDTO(location);
        }

        public async Task<LocationStudioDTO> GetByIdWithStudio(int id)
        {
            var location = await _repository.GetByIdWithStudio(id);
            if (location == null)
                return null;
            return new LocationStudioDTO(location);
        }

        public void Create(CreateLocationStudioDTO dto)
        {
            LocationStudio newLocation = new LocationStudio();
            newLocation.Country = dto.Country;
            newLocation.City = dto.City;
            newLocation.Street = dto.Street;
            newLocation.Number = dto.Number;
            newLocation.Zipcode = dto.Zipcode;
            newLocation.Studio = dto.Studio;

            _repository.Create(newLocation);
        }

        public async void Update(int id, CreateLocationStudioDTO dto)
        {
            var location = GetByIdAsync(id);
            if (location == null)
                return;

            location.Country = dto.Country;
            location.City = dto.City;
            location.Street = dto.Street;
            location.Number = dto.Number;
            location.Zipcode = dto.Zipcode;
            location.Studio = dto.Studio;

            _repository.Update(location);
        }

        public async void Delete(int id)
        {
            var location = GetByIdAsync(id);
            if (location == null)
                return;
            _repository.Delete(location);
        }

        public async void Delete()
        {
            var locations = _repository.GetAll();
            if (locations == null)
                return ;
            _repository.DeleteRange(locations);
        }

        public LocationStudio GetByIdAsync(int id)
        {
            var location = _repository.GetAll().FirstOrDefault(x => x.Id == id);
            return location;
        }
    }
}
