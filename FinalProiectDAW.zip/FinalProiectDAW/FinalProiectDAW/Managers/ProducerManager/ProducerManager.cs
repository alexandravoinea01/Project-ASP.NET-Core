﻿using FinalProiectDAW.Entities;
using FinalProiectDAW.Entities.DTOs;
using FinalProiectDAW.Repositories.ProducerRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Managers.ProducerManager
{
    public class ProducerManager : IProducerManager
    {
        private readonly IProducerRepository _repository;
        public ProducerManager(IProducerRepository repository)
        {
            _repository = repository;
        }
        public void Create(CreateProducerDTO dto)
        {
            Producer newProducer = new Producer();
            newProducer.FirstName = dto.FirstName;
            newProducer.LastName = dto.LastName;
            newProducer.ActiveSince = dto.ActiveSince;

            _repository.Create(newProducer);
        }

        public void Delete()
        {
            var producers = _repository.GetAll();
            if (producers == null)
                return;
            _repository.DeleteRange(producers);
        }

        public async void Delete(int id)
        {
            var producer = GetByIdAsync(id);
            if (producer == null)
                return;
            _repository.Delete(producer);
        }

        public async Task<List<ProducerDTO>> GetActiveSince(int year)
        {
            var producers = await _repository.GetActiveSince(year);
            if (producers.Count() == 0)
                return null;
            var producersToReturn = new List<ProducerDTO>();
            foreach (var producer in producers)
            {
                producersToReturn.Add(new ProducerDTO(producer));
            }
            return producersToReturn;
        }

        public async Task<List<ProducerDTO>> GetAll()
        {
            var producers = _repository.GetAll();
            if (producers.Count() == 0)
                return null;
            var producersToReturn = new List<ProducerDTO>();
            foreach (var producer in producers)
            {
                producersToReturn.Add(new ProducerDTO(producer));
            }
            return producersToReturn;
        }

        public Producer GetByIdAsync(int id)
        {
            var producer = _repository.GetAll().FirstOrDefault(x => x.Id == id);
            return producer;
        }

        public async Task<List<ProducerDTO>> GetByLastName(string lastName)
        {
            var producers = await _repository.GetByLastName(lastName);
            if (producers.Count() == 0)
                return null;
            var producersToReturn = new List<ProducerDTO>();
            foreach (var producer in producers)
            {
                producersToReturn.Add(new ProducerDTO(producer));
            }
            return producersToReturn;
        }

        public async void Update(int id, CreateProducerDTO dto)
        {
            var producer = GetByIdAsync(id);
            producer.FirstName = dto.FirstName;
            producer.LastName = dto.LastName;
            producer.ActiveSince = dto.ActiveSince;

            _repository.Update(producer);
        }
    }
}
