﻿using FinalProiectDAW.Entities;
using FinalProiectDAW.Entities.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Managers.ProducerManager
{
    public interface IProducerManager
    {
        Task<List<ProducerDTO>> GetByLastName(string lastName);
        Task<List<ProducerDTO>> GetActiveSince(int year);
        Producer GetByIdAsync(int id);
        Task<List<ProducerDTO>> GetAll();
        void Create(CreateProducerDTO dto);
        void Update(int id, CreateProducerDTO dto);
        void Delete();
        void Delete(int id);
    }
}
