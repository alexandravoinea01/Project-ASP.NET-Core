﻿using FinalProiectDAW.Entities;
using FinalProiectDAW.Entities.DTOs;
using FinalProiectDAW.Managers.MovieManager;
using FinalProiectDAW.Repositories.MovieRepository;
using FinalProiectDAW.Repositories.StudioRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieController : ControllerBase
    {
        private readonly IMovieManager _manager;
        public MovieController(IMovieManager manager)
        {
            _manager = manager;
        }

        [HttpGet]
        [Authorize(Policy = "BasicUser")]
        public async Task<IActionResult> GetAllMovies()
        {
            var moviesToReturn = await _manager.GetAllWithStudio();
            return Ok(moviesToReturn);
        }

        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> GetMovieById(int id)
        {
            var movie = _manager.GetByIdAsync(id);
            return Ok(movie);
        }

        [HttpGet]
        [Route("genre/{genre}")]
        public async Task<IActionResult> GetMovieByGenre(string genre)
        {
            var moviesToReturn = await _manager.GetByGenre(genre);
            return Ok(moviesToReturn);
        }

        [HttpGet]
        [Route("year/{year}")]
        public async Task<IActionResult> GetMovieByYear(int year)
        {
            var moviesToReturn = await _manager.GetByYear(year);
            return Ok(moviesToReturn);
        }

        [HttpGet]
        [Route("title/{title}")]
        public async Task<IActionResult> GetMovieByTitle(string title)
        {
            var movie = await _manager.GetByTitle(title);
            return Ok(movie);
        }

        [HttpPost]
        [Authorize(Policy = "Admin")]
        public async Task<IActionResult> CreateMovie(CreateMovieDTO dto)
        {
            _manager.Create(dto);
            return Ok();
        }

        [HttpPut]
        [Route("{id}")]
        [Authorize(Policy = "Admin")]
        public async Task<IActionResult> UpdateMovie(int id, CreateMovieDTO dto)
        {
            _manager.Update(id, dto);
            return Ok();
        }

        /*[HttpDelete]
         *[Authorize(Policy = "Admin")]
        public async Task<IActionResult> DeleteAllMovies()
        {
            _manager.Delete();
            return NoContent();
        }*/

        [HttpDelete]
        [Route("{id}")]
        [Authorize(Policy = "Admin")]
        public async Task<IActionResult> DeleteMovieById(int id)
        {
            _manager.Delete(id);
            var moviesToReturn = await _manager.GetAllWithStudio();
            return Ok(moviesToReturn);
        }
    }
}
