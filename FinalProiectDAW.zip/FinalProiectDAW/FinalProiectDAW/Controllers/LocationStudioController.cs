﻿using FinalProiectDAW.Entities;
using FinalProiectDAW.Entities.DTOs;
using FinalProiectDAW.Managers.LocationManager;
using FinalProiectDAW.Repositories.LocationStudioRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationStudioController : ControllerBase
    {
        private readonly ILocationStudioManager _manager;
        public LocationStudioController(ILocationStudioManager manager)
        {
            _manager = manager;
        }

        [HttpGet]
        [Authorize(Policy = "BasicUser")]
        public async Task<IActionResult> GetAllLocations()
        {
            var locationsToReturn = await _manager.GetAllLocationsWithStudio();
            return Ok(locationsToReturn);
        }

        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> GetLocationById(int id)
        {
            var location = _manager.GetByIdAsync(id);
            return Ok(location);
        }

        [HttpGet]
        [Route("city/{city}")]
        public async Task<IActionResult> GetLocationByCity(string city)
        {
            var location = await _manager.GetByCity(city);
            return Ok(location);
        }

        [HttpPost]
        [Authorize(Policy = "Admin")]
        public async Task<IActionResult> CreateLocation(CreateLocationStudioDTO dto)
        {
            _manager.Create(dto);
            var locationsToReturn = await _manager.GetAllLocationsWithStudio();
            return Ok(locationsToReturn);
        }

        [HttpPut]
        [Route("{id}")]
        [Authorize(Policy = "Admin")]
        public async Task<IActionResult> UpdateLocation(int id, CreateLocationStudioDTO dto)
        {
            _manager.Update(id, dto);
            return Ok();
        }

        [HttpDelete]
        [Route("{id}")]
        [Authorize(Policy = "Admin")]
        public async Task<IActionResult> DeleteLocation(int id)
        {
            _manager.Delete(id);
            var locationsToReturn = await _manager.GetAllLocationsWithStudio();
            return Ok(locationsToReturn);
        }

        /*[HttpDelete]
         *[Authorize(Policy = "Admin")]
        public async Task<IActionResult> DeleteAllLocations()
        {
            _manager.Delete();
            return NoContent();
        }*/
    }
}