﻿using FinalProiectDAW.Entities;
using FinalProiectDAW.Entities.DTOs;
using FinalProiectDAW.Managers.ProducerManager;
using FinalProiectDAW.Repositories.ProducerRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProducerController : ControllerBase
    {
        private readonly IProducerManager _manager;
        
        public ProducerController (IProducerManager manager)
        {
            _manager = manager;
        }

        [HttpGet]
        [Authorize(Policy = "BasicUser")]
        public async Task<IActionResult> GetAllProducers()
        {
            var producersToReturn = _manager.GetAll();
            return Ok(producersToReturn);
        }

        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> GetProducerById(int id)
        {
            var producer = _manager.GetByIdAsync(id);
            return Ok(producer);
        }

        [HttpGet]
        [Route("lastname/{lastname}")]
        public async Task<IActionResult> GetProducerByLastName(string lastname)
        {
            var producer = await _manager.GetByLastName(lastname);
            return Ok(producer);
        }

        [HttpGet]
        [Route("activesince/{activesince}")]
        public async Task<IActionResult> GetProducerByActiveSince(int activesince)
        {
            var producersToReturn = await _manager.GetActiveSince(activesince);
            return Ok(producersToReturn);
        }

        [HttpPost]
        [Authorize(Policy = "Admin")]
        public async Task<IActionResult> CreateProducer(CreateProducerDTO dto)
        {
            _manager.Create(dto);
            return Ok();
        }

        [HttpPut]
        [Route("{id}")]
        [Authorize(Policy = "Admin")]
        public async Task<IActionResult> UpdateProducer(int id, CreateProducerDTO dto)
        {
            _manager.Update(id, dto);
            return Ok();
        }

        /*[HttpDelete]
         *[Authorize(Policy = "Admin")]
        public async Task<IActionResult> DeleteAllProducers()
        {
            _manager.Delete();
            return NoContent();
        }*/

        [HttpDelete]
        [Route("{id}")]
        [Authorize(Policy = "Admin")]
        public async Task<IActionResult> DeleteProducerById(int id)
        {
            _manager.Delete(id);
            var producersToReturn = _manager.GetAll();
            return Ok(producersToReturn);
        }
    }
}
