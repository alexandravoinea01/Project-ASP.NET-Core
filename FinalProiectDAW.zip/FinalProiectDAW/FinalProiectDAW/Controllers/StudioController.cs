﻿using FinalProiectDAW.Entities;
using FinalProiectDAW.Entities.DTOs;
using FinalProiectDAW.Managers.StudioManager;
using FinalProiectDAW.Repositories.LocationStudioRepository;
using FinalProiectDAW.Repositories.StudioRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudioController : ControllerBase
    {
        private readonly IStudioManager _manager;
        public StudioController(IStudioManager manager)
        {
            _manager = manager;
        }

        [HttpGet]
        [Authorize(Policy = "BasicUser")]
        public async Task<IActionResult> GetAllStudios()
        {
            var studiosToReturn = await _manager.GetAllWithLocationAndMovies();
            return Ok(studiosToReturn);
        }

        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> GetStudioById(int id)
        {
            var studio = _manager.GetByIdAsync(id);
            return Ok(studio);
        }

        [HttpGet]
        [Route("name/{name}")]
        public async Task<IActionResult> GetStudioByName(string name)
        {
            var studio = await _manager.GetByName(name);
            return Ok(studio);
        }

        [HttpGet]
        [Route("foundingyear/{foundingyear}")]
        public async Task<IActionResult> GetStudioByFoundingYear(int foundingyear)
        {
            var studiosToReturn = await _manager.GetByFoundingYear(foundingyear);
            return Ok(studiosToReturn);
        }

        [HttpPost]
        [Authorize(Policy = "Admin")]
        public async Task<IActionResult> CreateStudio(CreateStudioDTO dto)
        {
            _manager.Create(dto);
            return Ok();
        }

        [HttpPut]
        [Route("{id}")]
        [Authorize(Policy = "Admin")]
        public async Task<IActionResult> UpdateStudio(int id, CreateStudioDTO dto)
        {
            _manager.Update(id, dto);
            return Ok();
        }

        /*[HttpDelete]
         *[Authorize(Policy = "Admin")]
        public async Task<IActionResult> DeleteAllStudios()
        {
            _manager.Delete();
            return NoContent();
        }*/

        [HttpDelete]
        [Route("{id}")]
        [Authorize(Policy = "Admin")]
        public async Task<IActionResult> DeleteById(int id)
        {
            _manager.Delete(id);
            var studiosToReturn = await _manager.GetAllWithLocationAndMovies();
            return Ok(studiosToReturn);
        }
    }
}
