﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Entities
{
    public class Studio
    {
        public int Id { get; set; }
        public string StudioName { get; set; }
        public int FoundingYear { get; set; }
        public string Owner { get; set; }
        public int LocationStudioId { get; set; }
        public LocationStudio LocationStudio { get; set; }
        public ICollection<Movie> Movies { get; set; }

    }
}
