﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Entities.DTOs
{
    public class MovieDTO
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int Year { get; set; }
        public string Genre { get; set; }
        public int Price { get; set; }
        public int StudioId { get; set; }
        public Studio Studio { get; set; }

        public MovieDTO (Movie movie)
        {
            this.Id = movie.Id;
            this.Title = movie.Title;
            this.Year = movie.Year;
            this.Genre = movie.Genre;
            this.Price = movie.Price;
            this.StudioId = movie.StudioId;
            this.Studio = movie.Studio;
        }
    }
}
