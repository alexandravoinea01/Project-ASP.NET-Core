﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Entities.DTOs
{
    public class StudioDTO
    {
        public int Id { get; set; }
        public string StudioName { get; set; }
        public int FoundingYear { get; set; }
        public string Owner { get; set; }
        public int LocationStudioId { get; set; }
        public LocationStudio LocationStudio { get; set; }
        public ICollection<Movie> Movies { get; set; }

        public StudioDTO (Studio studio)
        {
            this.Id = studio.Id;
            this.StudioName = studio.StudioName;
            this.FoundingYear = studio.FoundingYear;
            this.Owner = studio.Owner;
            this.LocationStudioId = studio.LocationStudioId;
            this.LocationStudio = studio.LocationStudio;
            this.Movies = studio.Movies;
        }
    }
}
