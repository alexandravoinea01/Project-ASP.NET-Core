﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Entities.DTOs
{
    public class CreateMovieDTO
    {
        public string Title { get; set; }
        public int Year { get; set; }
        public string Genre { get; set; }
        public int Price { get; set; }
        public int StudioId { get; set; }
        public Studio Studio { get; set; }
    }
}
