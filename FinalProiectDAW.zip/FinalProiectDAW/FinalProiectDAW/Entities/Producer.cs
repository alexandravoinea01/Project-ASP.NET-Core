﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalProiectDAW.Entities
{
    public class Producer
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int ActiveSince { get; set; }
        public ICollection<ProducerMovie> ProducerMovies { get; set; }
    }
}
